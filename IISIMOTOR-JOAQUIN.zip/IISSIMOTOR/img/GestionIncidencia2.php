<!DOCTYPE html>
<html>
   <head>
  <style>
  .abs-center {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
}
  </style>
   <script> 
	function abre(id_incidencia ,$boton) { 
	
			var altura=600;
			var anchura=630;
				
			var y=parseInt((window.screen.height/2)-(altura/2));
			var x=parseInt((window.screen.width/2)-(anchura/2));
			
			 elemento1 = document.getElementById('id_incidencia');
			 id=elemento1.value;
			 if($boton === 1){
	   		 window.open("ModificarIncidencia.php?id="+id,"Modificar Incidencia.",'width='+anchura+',height='+altura+',top='+y+',left='+x+',toolbar=no,location=no,status=no,menubar=no,scrollbars=no,directories=no,resizable=no'); 
   			}else {
   				window.open("MuestraIncidencia.php?id="+id,"Muestra Incidencia",'width='+anchura+',height='+altura+',top='+y+',left='+x+',toolbar=no,location=no,status=no,menubar=no,scrollbars=no,directories=no,resizable=no'); 
   			}
    return false; 
	} 
</script> 
   <meta charset = "utf-8">    
    <title>
      Buscar Incidencia
    </title>

    
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">

    <!-- Optional theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css" integrity="sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r" crossorigin="anonymous">

    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
   </head>
    <body >
    	 
           <div class="row">
  <div class="col-xs-4 col-sm-4 col-lg-4"></div>
  <div class="col-xs-4 col-sm-4 col-lg-4">
  	
  	<center><h1>Incidencia</h1></center>
  	
  	<form method="POST" class="form-in-line" action="GestionIncidencia2.php" >

  
  	<div class="form-group">
	    <label for="doc">Referencia</label>
	    <input type="text" name="id_incidencia" class="form-control" id="id_incidencia" >
	</div>

	
    <div class="form-group">
   
    <input type="submit" value="Buscar" class="btn btn-success" name="btn1" onclick="abre(id_incidencia,2)">
    <input type="submit" value="Borrar" class="btn btn-danger"  name="btn2">
    <input type="submit" value="Modificar" class="btn btn-warning" name="btn3" onclick="abre(id_incidencia,1)" >
	
	</div>
    
    </form>          
           		
		<?php
		if(isset($_POST['btn2'])){
			include ('gestionBD.php');
		
			$conexion =crearConexionBD();
			
			$id =$_POST['id_incidencia'];
								
			$borrado = $conexion->exec("DELETE FROM INCIDENCIA  WHERE ID_INCIDENCIA = $id");
			
			if($borrado === 1){
				 echo "  <script>alert(' Se ha borrado correctamente la incidencia.');</script> ";			
			}else if ($borrado === 0 ){
			     echo " <script>alert('No se ha podido realizar el borrado de la incidencia.');</script>";
			}
			
		     cerrarConexionBD($conexion);
		}
			
		?>
		</div>
		</div>
		</body >
		</html>