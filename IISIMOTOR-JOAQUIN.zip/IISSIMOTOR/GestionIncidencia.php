<!DOCTYPE html>
<html>
   <head>
 
  
  
   <meta charset = "utf-8">    
    <meta  name="viewport" content="width-device-with, initial-scale=1.0">
    <title>
      Gestor de Incidencias.
    </title>
    
	<script type="text/javascript" src="js/GESTIONI2.js"></script>
    <link rel="shortcut icon" type="image/png" href="img/issimotor.png" />
    <link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet' type='text/css'>
	<link  rel="stylesheet" href="css/main.css" type="text/css"/> 
    
   </head>
    
   <body style="height: 400px ; background-image: url('img/bentley-mulsanne-cars-luxury-sedan-blue-2016-interior-background-423249.jpg')">

        
              <form class="form"  style="height: 300px" form method="POST" action="GestionIncidencia.php" >
              	
                <h2> Gestión de las Incidencias. </h2>
                 
                  <p type="Referencia :"> <input type="text" name="id_incidencia" class="form-control" id="id_incidencia" >
                  
                  <button><input type="submit" value="Buscar" class="btn btn-success" name="btn1" onclick="abre(id_incidencia,2)"></a></button>
                   <button>  <input type="submit" value="Borrar" class="btn btn-danger"  name="btn2"></a></button>
                    <button> <input type="submit" value="Modificar" class="btn btn-warning" name="btn3" onclick="abre(id_incidencia,1)" ></a></button>
                 
                  <div>
                    <span>955 xxx xxx</span>
                    <span >servicioTec@IISSIMOTOR.com</span>
                  </div> 
    
               
                </form>
          		
		<?php include("php/GESTIONI.php"); ?>
		
		</body >
		</html>