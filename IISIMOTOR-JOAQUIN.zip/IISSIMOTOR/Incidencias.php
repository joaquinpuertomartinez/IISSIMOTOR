
<?php  include("php/incidencia.php");?>
 

<!DOCTYPE html>
<html>
	<head>
	<title>Mostrar datos de Incidencia . </title>
	<link rel="shortcut icon" type="image/png" href="img/issimotor.png" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js" type="text/javascript"></script>
    <script src="js/IncidenciaJS.js" type="text/javascript"></script>
   
		 <!-- Latest compiled and minified CSS -->
   
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">

    <!-- Optional theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css" integrity="sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r" crossorigin="anonymous">

    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
	
	</head>
	<body class="col-xs-12 col-md-8"  style=" width:100% ; height: 900px ;padding-left: 5% ; padding-right:5% ; padding-top: 12%; background-image: url('img/bentley-mulsanne-cars-luxury-sedan-blue-2016-interior-background-423249.jpg');background-repeat: no-repeat; background-size: cover;background-attachment: fixed; background-position: relative ">
	
	<div  class="table-responsive"style="background:#e6e6e6;border-radius: 20px 30px 20px;"   >	
		<Center><h1 style="font-weight: bold; display: inline;padding-top: 8px"> Base de datos de Incidencia .</h1></Center>
		 
		
		<table class="table table-hover" style="padding-top: 7px; "  >
			<tr>
				<th class="col-xs-12 col-md-8" style="width: 15%">Referencia de la Incidencia </th>
				<th class="col-xs-12 col-md-8" style="width: 15%" >Nombre  </th>
				<th class="col-xs-12 col-md-8" style="width: 15%">Apellidos </th>
				<th class="col-xs-12 col-md-8" style="width: 15%">Dni  </th>
				<th class="col-xs-12 col-md-8" style="width: 15%">Tipo de Incidencia  </th>
				<th class="col-xs-12 col-md-8" style="width: 15%">Fecha de Incidencia  </th>
				<th class="col-xs-12 col-md-8" style="width: 15%">Observacion  </th>
				
				<?php include("php/incidencia2.php");?>
			
				<nav>


		
		<div id="enlaces">
			<p style="font-weight: bold; display: inline; padding-left: 10px;padding-right: 5px">Páginas :  </p>
			<?php

				for( $pagina = 1; $pagina <= $total_paginas; $pagina++ )

					if ( $pagina == $pagina_seleccionada) { 	?>

						<span class="current"><?php echo $pagina; ?></span>

			<?php }	else { ?>

						<a href="Incidencias.php?PAG_NUM=<?php echo $pagina; ?>&PAG_TAM=<?php echo $pag_tam; ?>"><?php echo $pagina; ?></a>

			<?php } ?>

		
		
		</div>

		<form method="get" action="Incidencias.php" style="display: inline" >

			<input id="PAG_NUM" style="display: inline;padding-left: 10px;padding-right: 5px" name="PAG_NUM" type="hidden" value="<?php echo $pagina_seleccionada?>"/>

			 <p style="font-weight: bold; display: inline; padding-left: 10px;padding-right: 5px">Mostrando</p>

			<input id="PAG_TAM" name="PAG_TAM" style="padding-left: 10px" type="number"

				min="1" max="<?php echo $total_registros; ?>"

				value="<?php echo $pag_tam?>" autofocus="autofocus" />

			 <p style="font-weight: bold; display: inline;padding-left: 10px;padding-right: 5px">entradas de </p><?php echo $total_registros?>

			<input type="submit" value="Cambiar" class="btn btn-secondary">

		</form>

		

	</nav>

			</tr>
		</table>
		</div>
	</body>
</html>