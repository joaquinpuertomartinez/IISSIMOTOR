<?php
   
		include ('php/gestionBD.php');
		include ('php/gestion_incidencia.php');
		
			$conexion= crearConexionBD();
			$id=$_GET['id'];
			$consulta = " SELECT * FROM INCIDENCIA  WHERE ID_INCIDENCIA = $id";
			$stmt = $conexion->prepare($consulta);
			$stmt->setFetchMode(PDO::FETCH_ASSOC);
			// Ejecutamos
			$stmt->execute();
			
		   
		
		// Mostramos los resultados
		
		
		while ($row = $stmt->fetch()){
			
			$a=$row["ID_INCIDENCIA"] ;
			$b=$row["ID_CLIENTE"] ;
		   	$c=$row["TIPO_INCIDENCIA"];
			$d=$row["FECHA_INCIDENCIA"];
			$e=$row["OBSERVACION"];
		 
		}
    	 
		    		
			$crow=BuscaUsuario2($conexion, $b);
			
			$f=$crow["NOMBRE"] ;
			$g= $crow["APELLIDOS"] ;
		   	$h=$crow["DNI"];
			
		
	
			cerrarConexionBD($conexion);
		


?>