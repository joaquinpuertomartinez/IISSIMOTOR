
<?php
session_start();
?>


<!DOCTYPE html>
<html lang="es">
<head>
<title>IISSIMOTOR</title>
<link rel="stylesheet" href="/iissiMotor/img/bootstrap-4.3.1-dist">
<link rel="shortcut icon" type="image/png" href="/iissiMotor/img/image.png" />
<meta charset="utf-8">
<link  rel="stylesheet" href="css/index.css" type="text/css"/> 
</head>
<body id="page1">
<div class="body1">
	
<!-- header -->
	
		<header>
			
			<div class="wrapper" >
				<div class="left"style="padding-left:3%" >
					
					<div class="left"  id="logo"></div>
					<div class="right" >
				<h1 >
					IISSIMOTOR<span id="slogan">The best or nothing </span>
				</h1></div></div>
				<div class="right" >
				
					<nav style="padding-top:3%;pading-right:30%" >
						<ul id="menu"  >
							<li id="menu_active"><a href="index.html">Home</a></li>
							<li><a href="">Pedir Cita </a></li>
							<li> <a href="VistaIncidencia.php">Incidencia</a></li>       
                             <li><a href="factura.php">Facturación</a></li>
							
						
							<?php
							if (isset  ($_SESSION["login"])){
								echo '<li><a href="logout.php">Logout</a></li>';
								
							}else{
								echo '<li><a href="login.php">Login</a></li>';
							}
							
							?>
							
							</ul>
							
     						 
    						
					</nav>
				</div>
			</div>
		</header>
	
</div>
<div class="main">
	<div id="banner">
		<div class="text1">
			Calidad<span>Confort</span><p>Por que un viaje se disfruta mejor si vas seguro .</p>
		</div>
		<a href="#" class="button_top"></a>
	</div>
</div>
<!-- / header -->
<div class="main">

</div>
<div class="body2">
	<div class="main">
<!-- footer -->
		<footer>
			<a href="" target="_blank" rel="nofollow">www.miPaginaConcesionarioIISSIMOTOR.com</a><br>
			<a href="" target="_blank" rel="nofollow">atenciónAlclienteIISSIMOTOR@gmail.com</a>
			
		</footer>
<!-- / footer -->
	</div>
