<?php
   
    function incidencias($conexion, $paginacion){
    	
		
		$consulta = "SELECT * FROM INCIDENCIA ";
		return consulta_paginada($conexion, $consulta, $paginacion['PAG_NUM'], $paginacion["PAG_TAM"]);
	
    }
	
	
	
	
	function insertar_incidencia ($conexion,$id_usuario,$tipo,$fecha,$observacion){
    		
    	try{
			
		$consulta = "insert into INCIDENCIA VALUES (null,:id_usuario,:tipo,:fecha,:observacion)";
		$stmt= $conexion-> prepare($consulta);
		$stmt -> bindParam(":id_usuario", $id_usuario,PDO::PARAM_INT);
		$stmt -> bindParam(":tipo", $tipo,PDO::PARAM_STR);
		$stmt -> bindParam(":fecha", $fecha,PDO::PARAM_STR);
		$stmt -> bindParam(":observacion",$observacion,PDO::PARAM_STR);
		$stmt->execute();
		return $stmt;
		
		}catch(PDOException $ex){
			
		
			echo $ex ->getMessage();
			
		
		}
   
    }
	
	function BuscaUsuario ($conexion,$nombre,$apellidos,$dni){
				
		
		    $consulta = "SELECT id_cliente FROM CLIENTE WHERE Nombre ='$nombre' AND APELLIDOS = '$apellidos' AND DNI ='$dni'";
			
			
			$stmt = $conexion->prepare($consulta);
			$stmt->setFetchMode(PDO::FETCH_ASSOC);
			
			$stmt->execute();
			
			$row = $stmt->fetch();
			
			return $row['ID_CLIENTE'];
				
				
			}
		
	 function BuscaUsuario2 ($conexion,$id){
				
		
		    $consulta = "SELECT * FROM CLIENTE WHERE ID_CLIENTE = '$id'";
			
			
			$stmt = $conexion->prepare($consulta);
			$stmt->setFetchMode(PDO::FETCH_ASSOC);
			
			$stmt->execute();
			$row = $stmt->fetch();
			return  $row;
			
			
			
				
				
	 }
		
	
	
    
    
?>