<?php
		if(isset($_POST['btn2'])){
			include ('php/gestionBD.php');
		
			$conexion =crearConexionBD();
			
			$id =$_POST['id_incidencia'];
								
			$borrado = $conexion->exec("DELETE FROM INCIDENCIA  WHERE ID_INCIDENCIA = $id");
			
			if($borrado === 1){
				 echo "  <script>alert(' Se ha borrado correctamente la incidencia.');</script> ";			
			}else if ($borrado === 0 ){
			     echo " <script>alert('No se ha podido realizar el borrado de la incidencia.');</script>";
			}
			
		     cerrarConexionBD($conexion);
		}
			
		?>
		