<?php
	
		function id($id_incidencia){
					
				include ('php/gestionBD.php');
				$conexion= crearConexionBD();
				
			$borrado = $conexion->exec("DELETE FROM INCIDENCIA  WHERE ID_INCIDENCIA = $id_incidencia");
				cerrarConexionBD($conexion);
			if($borrado === 1){
				 echo " <script> alert('Se ha borrado correctamente la incidencia.');</script> ";			
			}else if ($borrado === 0 ){
			     echo " <script>alert('No se ha podido realizar el borrado de la incidencia.');</script>";
			}
			
		}	
		?>