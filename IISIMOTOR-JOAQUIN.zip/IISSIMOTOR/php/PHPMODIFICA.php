<?php 
        
       
        
        if(isset($_POST['btn1'])){
				
		include ('php/gestionBD.php');
		include('php/gestion_incidencia.php');
		
		$conexion= crearConexionBD();
			
			
			
		
			$id_incidencia = $_POST['id_incidencia'];
			$nombre_cliente = $_POST['nombre_cliente'];
			$apellidos= $_POST['apellidos'];
			$dni = $_POST['dni'];
			$tipo= $_POST['tipo_incidencia'];
			$fecha= $_POST['fecha'];
			$observacion= $_POST['observacion'];
			$id_cliente = BuscaUsuario($conexion, $nombre_cliente, $apellidos, $dni);
			
			$consulta = " UPDATE INCIDENCIA SET  id_cliente = $id_cliente, tipo_incidencia = '$tipo', fecha_incidencia='$fecha', observacion='$observacion' WHERE id_incidencia = '$id_incidencia'";
			
			$stmt = $conexion->query($consulta);
			alert("Se ha actualizado correctamente ");
			
		
			cerrarConexionBD($conexion);
			echo " <script>alert(' Se ha actualizado la incidencia ,  pulsa cerar para salir .!!');</script>";
			
		}
		
		?>