<?php
						include('php/gestion2.php') ;
						
						
						foreach ($filas as $lista_incidencia) {
						
						$id_incidencia=$lista_incidencia['ID_INCIDENCIA'];
							
						$id_cliente= $lista_incidencia['ID_CLIENTE']; 
						
						 $crow=BuscaUsuario2($conexion, $id_cliente);
						
						$q= $crow["NOMBRE"];
						
						$a=$crow["APELLIDOS"];
						
						$b= $crow["DNI"];
						
						$c=$lista_incidencia['TIPO_INCIDENCIA'];
						$d=$lista_incidencia['FECHA_INCIDENCIA'];
						$e=$lista_incidencia['OBSERVACION'];
					   
					  
															
						echo "<tr >";
						 echo " <form class='form' name='f' id='f' form method='POST' action='Incidencias.php' >";
							echo "<td  >";
							echo "<input type='text' name='id_incidencia' class='form-control ' id='id_incidencia' value='$id_incidencia ' readonly='readonly' >";
								// echo $lista_incidencia['ID_INCIDENCIA'] ;
					    	echo "</td>";
							
							echo "<td>";
							 echo "<input type='text' class='form-control ' id='q' value=' $q' name='q' readonly='readonly' >";
								//echo $crow["NOMBRE"];
							echo "</td>";
							echo "<td>";
							echo "<input type='text'  class='form-control ' id='a' value=' $a' name='a' readonly='readonly' >";
								//echo $crow["APELLIDOS"];
							echo "</td>";
							echo "<td>";
							echo "<input type='text'  class='form-control ' id='b' value=' $b' name='b' readonly='readonly' >";
								//echo $crow["DNI"];
							echo "</td>";
							echo "<td>";
							echo "<input type='text' class='form-control ' id='c' value=' $c'  name='c' readonly='readonly' >";
								//echo $lista_incidencia['TIPO_INCIDENCIA'];
							echo "</td>";
							
							echo "<td>";
							echo "<input type='text' class='form-control ' id='d' value=' $d' name='d' readonly='readonly' >";
								//echo $lista_incidencia['FECHA_INCIDENCIA'];
								
							echo "</td>";
							
							echo "<td>";
								echo "<input type='text'  class='form-control 'value=' $e' id='e'  name='e' readonly='readonly' >";
								//echo $lista_incidencia['OBSERVACION'];
							echo "</td>";
							cerrarConexionBD($conexion);
							echo"<td class='boton'><input type ='button' value='Modificar' class='btn btn-info' ></td>";
						    // echo"<td ><input type ='button'  value='Borrar'  class='btn btn-danger'  onclick =' id(); '></td>";
						   
						  
							
							
							echo "</form>";
							
						echo "</tr>";  
			
		}
			
		 
					
				?>