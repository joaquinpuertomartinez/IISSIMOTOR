<?php 
        
      
        if(isset($_POST['btn1'])){
				
			include('php/gestionBD.php');
			include('php/gestion_incidencia.php');
			
			$conexion = crearConexionBD();
						
			$nombre_cliente =$_POST['nombre_cliente'];
			$apellidos=$_POST['apellidos'];
			$dni=$_POST['dni'];
			$tipo=$_POST['tipo'];
			$fecha=$_POST['fecha'];
			$observacion=$_POST['observacion'];
			$id_cliente = BuscaUsuario($conexion, $nombre_cliente, $apellidos, $dni);
			
			try{
			$consulta ="INSERT INTO INCIDENCIA (ID_CLIENTE,TIPO_INCIDENCIA,FECHA_INCIDENCIA,OBSERVACION) values ('$id_cliente','$tipo','$fecha','$observacion')";
			$stmt = $conexion ->prepare($consulta);
			$stmt->execute();
			cerrarConexionBD($conexion);
			echo " <script>alert(' Se ha Generado la Incidencia !!');</script>";	
			
			}catch(PDOException $ex){
			echo $ex ->getMessage();
			}
				}
            
      			
		
			
			
          ?>       