<?php include("php/muestra1.php");
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset = "utf-8">    
         <meta  name="viewport" content="width-device-with, initial-scale=1.0"/>
          <script src="js/cerrar.js" type="text/javascript"></script>
      
         <title>
      	Modificar Incidencia
    	</title>
        <link  rel="stylesheet" href="css/muestras.css" type="text/css"/> 
        <link rel="shortcut icon" type="image/png" href="img/issimotor.png" />
        <link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet' type='text/css'>
    </head>
    <body   style=" background-image: url('img/bentley-mulsanne-cars-luxury-sedan-blue-2016-interior-background-423249.jpg')">
               
         <form class="form">
             <div class = "padre" >
                 <div class  ="hijo" style =" float:right " >
                
                  <h2> Datos del cliente .</h2>
                  <p type="Nombre :"><input type="text" name="nombre" class="form-control " id="nombre" value=<?php echo $f ;?> readonly="readonly" ></input></p>
                  <p type="Apellidos:"><input type="text" name="apellidos" class="form-control " id="apellidos" value=<?php echo $g ;?> readonly="readonly" ></p>
                  <p type="Dni :"><input type="text" name="dni" class="form-control " id="dni" value=<?php echo $h ;?> readonly="readonly" ></p>
                              
                  <img src="img/image .png" style=" padding-left:15% ; padding-top:20%"></img>
                  <div class ="div ">
                    <span>955 xxx xxx</span>
                    <span > servicioTec@IISSIMOTOR.com</span>
                  </div>  </div> 
                  <div class  ="hijo"  >
               	 <h2> Datos de la Incidencia .</h2>
                  <p type="Referencia :"> <input type="text" name="id_incidencia" class="form-control " id="id_incidencia"  value=<?php echo $a ;?>  readonly="readonly" ></p>
                  <p type="Tipo de incidencia :"><input type="text" name="tipo_incidencia" class="form-control " id="tipo_incidencia" value=<?php echo $c ;?> readonly="readonly" ></p>
                  <p type="Fecha :"> <input type="text" name="fecha" class="form-control " id="fecha" value=<?php echo $d ;?> readonly="readonly"></input></p>
                  <p type="Observación :"><input type="text" name="observacion" class="form-control " id="observacion" value=<?php echo $e ;?> readonly="readonly"> </p>	  
                  <button ><input type="button" value="Cerrar"  name="btn1" onclick="cerrar()" ></button>
                  <div class ="div ">
                    <span> 955 xxx xxx</span>
                    <span > atencionCli@IISSIMOTOR.com</span>
                  </div> 
                  </div>
                  
                  </div>
                  </form>
                   
    </body>
</html>