
<?php 
   /*include("php/Muestra2.php");*/
		
?>
<!DOCTYPE html>

<html>
   <head>
    <meta  name="viewport" content="width-device-with, initial-scale=1.0"/>
   
   <meta charset = "utf-8">    
    <script src="js/cerrar.js" type="text/javascript"></script>
    <title>
      Modificar Incidencia
    </title>

 	<link rel="shortcut icon" type="image/png" href="img/issimotor.png" />
    <link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet' type='text/css'>
	<link  rel="stylesheet" href="css/main.css" type="text/css"/> 
   </head>

       <body style="height: 900px ; background-image: url('img/bentley-mulsanne-cars-luxury-sedan-blue-2016-interior-background-423249.jpg')">

        
              <form class="form"  style="height: 800px" form method="POST" action="ModificarIncidencia.php"  >
              
                <h2> Incidencia </h2>
                  <p type="Referencia:"><input type="text" name="id_incidencia" class="form-control "  id="id_incidencia" required"   ></p>
                 
                  <p type="Nombre :"><input type="text" name="nombre_cliente" class="form-control"  id="nombre_cliente"></p>
                 
                  <p type="Apellidos : "><input type="text" name="apellidos" class="form-control"  id="apellidos"></input></p>
                 
                  <p type="Dni: "><input type="text" name="dni" class="form-control"  id="dni"></p>
                 
                  <p type="Tipo de incidencia :"><input type="text" name="tipo_incidencia"  class="form-control" id="tipo_incidencia"></input></p>
                 
                  <p type="Fecha : "><input type="text" name="fecha"  class="form-control" id="fecha"></input></p>
                 
                  <p type="Observacion : "><input type="text" name="observacion" class="form-control" id="observacion"></input></p>
                 
                  <button><input type="submit" value="Enviar incidencia"  formnovalidate= "POST" name="btn1"  /></button>
                  <button ><input type="button" value="Cerrar"  name="btn1" onclick="cerrar()" ></button>
                 
                  <div>
                    <span>955 xxx xxx</span>
                    <span >servicioTec@IISSIMOTOR.com</span>
                  </div> 
    
               
                </form>
           <?php include("php/PHPMODIFICA.php");?>
		
		</body >
		</html>