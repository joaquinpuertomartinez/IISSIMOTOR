<!DOCTYPE html>
<html>
   <head>
 
   <meta charset = "utf-8">    
    <meta  name="viewport" content="width-device-with, initial-scale=1.0">
    <title>
      Gestor de Incidencias.
    </title>
    
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">

    <!-- Optional theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css" integrity="sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r" crossorigin="anonymous">

    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
    <link rel="shortcut icon" type="image/png" href="img/issimotor.png" />
    <link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet' type='text/css'>
	<link  rel="stylesheet" href="css/main.css" type="text/css"/>  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">

   </head>
    
   <body style="height: 100% ; background-image: url('img/bentley-mulsanne-cars-luxury-sedan-blue-2016-interior-background-423249.jpg')">

        
              <form class="form"  style="height: 300px" >
              	  <center style="padding-top: 7%"> <input class="btn btn-primary btn-lg" type="button" value="Gestion Incidencia"  name="btn1" onclick = "location='GestionIncidencia.php'"></center>
               	  <center style="padding-top: 7% "> <input class="btn btn-primary btn-lg" type="button" value="Añadir Incidencia"  name="btn2" onclick = "location='VistaIncidencia.php'" ></center> 
                   <center  style="padding-top: 7% "> <input class="btn btn-primary btn-lg" type="button" value="Base de datos"  name="btn3" onclick = "location='Incidencias.php'"></center>
                  <div>
                    <span>955 xxx xxx</span>
                    <span >servicioTec@IISSIMOTOR.com</span>
                  </div> 
    
               
                </form>
              				
		</body >
		</html>