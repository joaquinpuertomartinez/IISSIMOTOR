	function cerrar() {
   
   	 window.close();  // Closes the new window
   			}