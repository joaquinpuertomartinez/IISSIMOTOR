$(document).ready(function(){
			        $(".boton").click(function(){
			 
			            var valor="";
			 			var anchura=630;
				  		var altura=600;
						var y=parseInt((window.screen.height/2)-(altura/2));
						var x=parseInt((window.screen.width/2)-(anchura/2));
			            
			            // Obtenemos todos los valores contenidos en los <td> de la fila
			            
			            // seleccionada
			            id= $(this).parents("tr").find("td")[0].innerHTML;
			            
			            
			          
						window.open("ModificarIncidencia.php?id="+id,"Modificar Incidencia.",'width='+anchura+',height='+altura+',top='+y+',left='+x+',toolbar=no,location=no,status=no,menubar=no,scrollbars=no,directories=no,resizable=no');
			        });
			    });
			   