
function abre(id_incidencia ,$boton) { 
	
			var altura=600;
			var anchura=630;
				
			var y=parseInt((window.screen.height/2)-(altura/2));
			var x=parseInt((window.screen.width/2)-(anchura/2));
			
			 elemento1 = document.getElementById('id_incidencia');
			 id=elemento1.value;
			 if($boton === 1){
	   		 window.open("ModificarIncidencia.php?id="+id,"Modificar Incidencia.",'width='+anchura+',height='+altura+',top='+y+',left='+x+',toolbar=no,location=no,status=no,menubar=no,scrollbars=no,directories=no,resizable=no'); 
   			}else {
   				window.open("MuestraIncidencia.php?id="+id,"Muestra Incidencia",'width='+anchura+',height='+altura+',top='+y+',left='+x+',toolbar=no,location=no,status=no,menubar=no,scrollbars=no,directories=no,resizable=no'); 
   			}
    return false; }