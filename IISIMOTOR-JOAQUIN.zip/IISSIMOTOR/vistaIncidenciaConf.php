<?php
    include ('gestionBD.php');
	$conexion = crearConexionBD();
	$id_usuario= $_POST['id_usuario'];
	$tipo =$_POST['tipo'];
	$fecha=$_POST['fecha'];
	$observacion=$_POST['observacion'];
	
	include ('gestion_incidencia.php');
	insertar_incidencia ($conexion,$id_usuario,$tipo,$fecha,$observacion);
	

?>
<!DOCTYPE html>
<html>
 <head>
    <meta charset = "utf-8">    
    
    <title>
      IISSIMOTOR-INCIDENCIAS
    </title>
    <link rel="shortcut icon" type="image/png" href="/iissiMotor/img/image.png" />
    <link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" type="text/css" href="css/vistaIncidenciaConf.css" />
</head>
<body>
    
                <form class="form"  action="/IISSI/IISSIMOTOR/vistaIncidenciaConf.php" method="POST" >
                <h2> Incidencia </h2>
                 
                   
                  <p  style="margin:10px 0;padding-bottom:10px;color:#78788c;padding-top:10px"> <b>Su incidencia ha sido generada con exito</b> , puede descargargar su justificante de incidencia haciendo clic en el icono de descarga . 
                        Gracias por su colaboración .</p>
                          
                  <img src="/iissiMotor/img/descarga.png" style="width:60px;height:60px; padding-top:1.5%  ">
                   <button><input type="submit" value="Terminar"  formnovalidate= "POST" /></a></button>
                  <div>
                    <span>  955 xxx xxx</span>
                    <span > servicioTec@IISSIMOTOR.com</span>
                  </div> 
                  </form>
    
    
</body>
</html>